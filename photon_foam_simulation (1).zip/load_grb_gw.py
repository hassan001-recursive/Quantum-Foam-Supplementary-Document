# load_grb_gw.py
import numpy as np
import matplotlib.pyplot as plt

ell_p = 1.616e-35
c = 3e8

def load_grb_gw_event():
    return {
        'D_Mpc': 40.0,
        'lambda_m': 1.24e-11,
        'observed_delay_s': 1.7
    }

def foam_delay_estimate(D_Mpc, lambda_m):
    D = D_Mpc * 3.086e22
    return (ell_p * D) / (c * lambda_m)

if __name__ == "__main__":
    event = load_grb_gw_event()
    delta_t_foam = foam_delay_estimate(event['D_Mpc'], event['lambda_m'])
    print("Observed GRB-GW delay:", event['observed_delay_s'], "s")
    print("Predicted quantum foam delay:", delta_t_foam, "s")

    plt.bar(['Observed', 'Quantum Foam'], [event['observed_delay_s'], delta_t_foam], color=['gray', 'red'])
    plt.ylabel("Arrival Time Delay (s)")
    plt.title("GRB–GW Delay vs. Quantum Foam Prediction")
    plt.grid(True, axis='y')
    plt.tight_layout()
    plt.show()
