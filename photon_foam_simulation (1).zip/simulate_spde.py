# simulate_spde.py
# Simulates 1D stochastic evolution of photon field E(x,t) with quantum foam noise

import numpy as np
import matplotlib.pyplot as plt
from scipy.fft import fft, ifft, fftfreq

# --- Physical Parameters ---
c = 3e8                    # Speed of light (m/s)
L = 1e-3                   # Spatial domain size (m)
N = 1024                  # Number of spatial points
dx = L / N                # Spatial step
x = np.linspace(0, L, N, endpoint=False)

dt = 1e-15                # Time step (s)
T_total = 1e-12           # Total simulation time (s)
Nt = int(T_total / dt)    # Number of time steps
times = np.linspace(0, T_total, Nt)

lambda_0 = 500e-9         # Wavelength (m)
k0 = 2 * np.pi / lambda_0 # Central wavenumber

# --- Initialize Field ---
E0 = np.exp(1j * k0 * x) * np.exp(-((x - L/2)**2) / (2 * (L/20)**2))
E = E0.copy()

# --- Fourier Setup for Derivatives ---
kx = 2 * np.pi * fftfreq(N, d=dx)

# --- Noise Parameters ---
sigma = 1e12              # Strength of quantum foam noise (1/s)
correlation_length = L / 10
noise_spectrum = np.exp(-0.5 * (kx * correlation_length)**2)

# --- Storage for Results ---
results = []
decoherence = []
spectrum_peaks = []

# --- Main Evolution Loop ---
for n in range(Nt):
    t = times[n]

    # Generate correlated noise in Fourier space
    noise_real = np.random.normal(0, 1, N)
    noise_fft = fft(noise_real) * np.sqrt(noise_spectrum)
    xi = np.real(ifft(noise_fft)) * sigma * np.sqrt(dt)

    # Euler update with deterministic and stochastic terms
    dE_dx = ifft(1j * kx * fft(E))
    E += dt * (1j * c * dE_dx) + xi * E * dt

    if n % 100 == 0:
        results.append(E.copy())

        # --- Observable: Decoherence ---
        decoherence_val = np.abs(np.vdot(E0, E)) / np.linalg.norm(E0)**2
        decoherence.append(decoherence_val)

        # --- Observable: Spectral Peak ---
        E_fft = fft(E)
        power_spectrum = np.abs(E_fft)**2
        peak_freq = kx[np.argmax(power_spectrum)]
        spectrum_peaks.append(peak_freq)

# --- Plot Final Intensity ---
plt.figure(figsize=(10,4))
plt.plot(x * 1e3, np.abs(E)**2)
plt.title("Final Photon Field Intensity |E(x)|^2")
plt.xlabel("x (mm)")
plt.ylabel("Intensity")
plt.grid(True)
plt.tight_layout()
plt.show()

# --- Plot Decoherence ---
plt.figure(figsize=(8,4))
plt.plot(times[::100]*1e12, decoherence)
plt.title("Decoherence Functional over Time")
plt.xlabel("Time (ps)")
plt.ylabel("|<E(t), E(0)>| / ||E(0)||^2")
plt.grid(True)
plt.tight_layout()
plt.show()

# --- Plot Spectral Peak Drift ---
plt.figure(figsize=(8,4))
plt.plot(times[::100]*1e12, np.array(spectrum_peaks) * 1e-3)
plt.title("Spectral Peak Drift (k-space)")
plt.xlabel("Time (ps)")
plt.ylabel("Peak Spatial Frequency (rad/mm)")
plt.grid(True)
plt.tight_layout()
plt.show()
