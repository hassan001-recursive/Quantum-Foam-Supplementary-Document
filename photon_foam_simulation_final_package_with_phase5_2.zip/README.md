# Photon-Foam Simulation Framework

This repository provides a simulation and empirical comparison framework for testing the hypothesis that photons propagate with embedded Planck-scale stochastic fluctuations — "quantum foam".

## Modules

- `simulate_spde.py`: Simulates SPDE evolution of photon field under quantum foam noise.
- `load_solar_spectra.py`: Compares solar line shifts against foam predictions.
- `load_pulsar_toa.py`: Evaluates delay jitter in pulsar TOAs.
- `load_grb_gw.py`: Analyzes GRB–GW delay vs. quantum foam effects.

## Requirements

```bash
pip install numpy scipy matplotlib
```

## Usage

Run any script as a standalone module. Modify parameters as needed.

## License

MIT License
