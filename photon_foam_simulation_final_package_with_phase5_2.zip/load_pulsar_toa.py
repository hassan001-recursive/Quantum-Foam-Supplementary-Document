# load_pulsar_toa.py
import numpy as np
import matplotlib.pyplot as plt

ell_p = 1.616e-35
c = 3e8

def load_mock_pulsar_data():
    times = np.linspace(0, 10*365, 2000)
    residuals = np.random.normal(0, 0.15, size=times.shape)
    return times, residuals

def foam_delay_estimate(D_kpc=1.0, wavelength_m=0.21):
    D = D_kpc * 3.086e19
    return (ell_p * D) / (c * wavelength_m)

if __name__ == "__main__":
    times, residuals = load_mock_pulsar_data()
    delta_t_foam = foam_delay_estimate()
    print("Predicted quantum foam delay:", delta_t_foam * 1e9, "ns")
    print("Observed residual std deviation:", np.std(residuals), "us")

    plt.figure(figsize=(8,4))
    plt.hist(residuals * 1e3, bins=50, alpha=0.7)
    plt.axvline(delta_t_foam * 1e6, color='red', linestyle='--')
    plt.title("Pulsar Timing Residuals vs. Quantum Foam Prediction")
    plt.xlabel("Residual (ns)")
    plt.ylabel("Counts")
    plt.grid(True)
    plt.tight_layout()
    plt.show()
