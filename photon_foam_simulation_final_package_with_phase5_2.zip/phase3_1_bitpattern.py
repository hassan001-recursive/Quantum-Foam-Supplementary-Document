
import numpy as np
from scipy.fft import fft, ifft, fftfreq

# Parameters
c = 3e8
L = 1e-3
N = 2048
dx = L / N
x = np.linspace(0, L, N, endpoint=False)
dt = 1e-15
T_total = 2e-13
Nt = int(T_total / dt)
bit_profile = np.zeros_like(x)
bit_profile[(x > 0.4e-3) & (x < 0.6e-3)] = 1.0
envelope = np.exp(-((x - L/2)**2) / (2 * (L/10)**2))
E0 = (bit_profile * envelope).astype(np.complex128)
E = E0.copy()
kx = 2 * np.pi * fftfreq(N, d=dx)
correlation_length = L / 10
noise_spectrum = np.exp(-0.5 * (kx * correlation_length)**2)
sigma = 1e9

for _ in range(Nt):
    noise_real = np.random.normal(0, 1, N)
    xi = np.real(ifft(fft(noise_real) * np.sqrt(noise_spectrum)))
    g = sigma * np.tanh(xi)
    dE_dx = ifft(1j * kx * fft(E))
    E += dt * (1j * c * dE_dx) + g * E * dt
