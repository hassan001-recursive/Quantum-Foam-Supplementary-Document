
import numpy as np
from scipy.fft import fft, ifft, fftfreq
from scipy.optimize import curve_fit

# Parameters
c = 3e8
L = 1e-3
N = 2048
dx = L / N
x = np.linspace(0, L, N, endpoint=False)
dt = 1e-15
T_total = 2e-13
Nt = int(T_total / dt)
kx = 2 * np.pi * fftfreq(N, d=dx)
correlation_length = L / 10
noise_spectrum = np.exp(-0.5 * (kx * correlation_length)**2)

sigma_vals = np.logspace(7, 10, 6)
gamma_vals = []
E0 = np.exp(-((x - L/2)**2) / (2 * (L/20)**2)).astype(np.complex128)

def exp_decay(t, a, gamma): return a * np.exp(-gamma * t)

for sigma in sigma_vals:
    E = E0.copy()
    decoherence = []
    for n in range(Nt):
        noise_real = np.random.normal(0, 1, N)
        xi = np.real(ifft(fft(noise_real) * np.sqrt(noise_spectrum)))
        g = sigma * np.tanh(xi)
        dE_dx = ifft(1j * kx * fft(E))
        E += dt * (1j * c * dE_dx) + g * E * dt
        if n % 20 == 0:
            inner_prod = np.vdot(E0, E)
            norm_sq = np.linalg.norm(E0)**2
            decoherence.append(np.abs(inner_prod) / norm_sq)
    try:
        t_sample = np.linspace(0, T_total, len(decoherence))
        popt, _ = curve_fit(exp_decay, t_sample, decoherence, p0=(1, 1e10))
        gamma_vals.append(popt[1])
    except RuntimeError:
        gamma_vals.append(np.nan)
