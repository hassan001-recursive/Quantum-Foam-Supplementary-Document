
import numpy as np
from scipy.fft import fft, ifft, fftfreq
from scipy.optimize import curve_fit

# Parameters
c = 3e8
L = 1e-3
N = 2048
dx = L / N
x = np.linspace(0, L, N, endpoint=False)
dt = 1e-15
T_total = 2e-13
Nt = int(T_total / dt)
kx = 2 * np.pi * fftfreq(N, d=dx)
correlation_length = L / 10
noise_spectrum = np.exp(-0.5 * (kx * correlation_length)**2)
sigma = 1e8

phi0 = np.exp(-((x - L/2)**2) / (2 * (L/20)**2)).astype(np.complex128)
phi = phi0.copy()
decoherence = []

def exp_decay(t, a, gamma): return a * np.exp(-gamma * t)

for n in range(Nt):
    noise_real = np.random.normal(0, 1, N)
    xi = np.real(ifft(fft(noise_real) * np.sqrt(noise_spectrum)))
    g = sigma * np.tanh(xi)
    dphi_dx = ifft(1j * kx * fft(phi))
    phi += dt * (1j * c * dphi_dx) + g * phi * dt
    if n % 20 == 0:
        inner_prod = np.vdot(phi0, phi)
        norm_sq = np.linalg.norm(phi0)**2
        decoherence.append(np.abs(inner_prod) / norm_sq)

t_sample = np.linspace(0, T_total, len(decoherence))
params, _ = curve_fit(exp_decay, t_sample, decoherence, p0=(1.0, 1e10))
gamma_scalar = params[1]
