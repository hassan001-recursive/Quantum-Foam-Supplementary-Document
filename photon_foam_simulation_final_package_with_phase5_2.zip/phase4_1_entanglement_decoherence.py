
import numpy as np
from scipy.fft import fft, ifft, fftfreq

# Parameters
c = 3e8
L = 1e-3
N = 2048
dx = L / N
x = np.linspace(0, L, N, endpoint=False)
dt = 1e-15
T_total = 2e-13
Nt = int(T_total / dt)
kx = 2 * np.pi * fftfreq(N, d=dx)
correlation_length = L / 10
noise_spectrum = np.exp(-0.5 * (kx * correlation_length)**2)
sigma = 1e9

# Initial field (entangled state)
phi0 = np.exp(-((x - L/2)**2) / (2 * (L/20)**2)).astype(np.complex128)
phi1 = phi0.copy()
phi2 = phi0.copy()

# Store fidelity over time
entanglement_fidelity = []

# SPDE evolution for both channels
for n in range(Nt):
    xi1 = np.real(ifft(fft(np.random.normal(0, 1, N)) * np.sqrt(noise_spectrum)))
    g1 = sigma * np.tanh(xi1)
    dphi1_dx = ifft(1j * kx * fft(phi1))
    phi1 += dt * (1j * c * dphi1_dx) + g1 * phi1 * dt

    xi2 = np.real(ifft(fft(np.random.normal(0, 1, N)) * np.sqrt(noise_spectrum)))
    g2 = sigma * np.tanh(xi2)
    dphi2_dx = ifft(1j * kx * fft(phi2))
    phi2 += dt * (1j * c * dphi2_dx) + g2 * phi2 * dt

    if n % 20 == 0:
        numerator = np.vdot(phi1, phi2)
        denom = np.linalg.norm(phi1) * np.linalg.norm(phi2)
        entanglement_fidelity.append(np.abs(numerator / denom))
