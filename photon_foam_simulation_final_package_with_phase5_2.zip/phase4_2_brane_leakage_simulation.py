
import numpy as np
from scipy.fft import fft, ifft, fftfreq

# Parameters
c = 3e8
L = 1e-3
N = 2048
dx = L / N
x = np.linspace(0, L, N, endpoint=False)
dt = 1e-15
T_total = 2e-13
Nt = int(T_total / dt)
kx = 2 * np.pi * fftfreq(N, d=dx)
correlation_length = L / 10
noise_spectrum = np.exp(-0.5 * (kx * correlation_length)**2)
sigma = 1e9
lambda_coupling = 1e8

# Initial fields
phi_visible = np.exp(-((x - L/2)**2) / (2 * (L/20)**2)).astype(np.complex128)
phi_hidden = np.zeros_like(phi_visible)

energy_visible = []
energy_hidden = []

# Evolution
for n in range(Nt):
    xi_visible = np.real(ifft(fft(np.random.normal(0, 1, N)) * np.sqrt(noise_spectrum)))
    g_visible = sigma * np.tanh(xi_visible)
    dphi_dx_visible = ifft(1j * kx * fft(phi_visible))
    phi_visible += dt * (1j * c * dphi_dx_visible) + g_visible * phi_visible * dt + lambda_coupling * phi_hidden * dt

    xi_hidden = np.real(ifft(fft(np.random.normal(0, 1, N)) * np.sqrt(noise_spectrum)))
    g_hidden = sigma * np.tanh(xi_hidden)
    dphi_dx_hidden = ifft(1j * kx * fft(phi_hidden))
    phi_hidden += dt * (1j * c * dphi_dx_hidden) + g_hidden * phi_hidden * dt + lambda_coupling * phi_visible * dt

    energy_visible.append(np.sum(np.abs(phi_visible)**2))
    energy_hidden.append(np.sum(np.abs(phi_hidden)**2))
