
import numpy as np
import matplotlib.pyplot as plt

# Parameters
T_total = 1e-6  # 1 microsecond
dt = 1e-9
Nt = int(T_total / dt)
t_series = np.linspace(0, T_total, Nt)

# Constants
pi = np.pi
e_charge = np.exp(1)
mass_energy = 1e-30
kappa = 1e20
r_exp = 3.5

# Compute energy layers
energy_layers = []
for t in t_series:
    layer_energy = np.sqrt(mass_energy**pi) + pi**np.log(np.abs(e_charge)) + kappa * (t**r_exp)
    energy_layers.append(layer_energy)

# Plot (optional if running standalone)
plt.plot(t_series * 1e6, energy_layers)
plt.xlabel("Time (μs)")
plt.ylabel("Energy (arb. units)")
plt.title("Recursive Energy Layering Over Time")
plt.grid(True)
plt.tight_layout()
plt.show()
