# load_solar_spectra.py
# Interface to load and process solar spectra (FTS) from NSO for foam-induced residual detection

import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import find_peaks
from scipy.interpolate import interp1d

def load_mock_solar_spectrum():
    lam = np.linspace(629.5, 630.8, 5000)
    profile = 1 - 0.5 * np.exp(-((lam - 630.15)**2) / (2 * (0.02)**2))
    noise = np.random.normal(0, 0.002, size=lam.shape)
    observed = profile + noise
    return lam, observed

def foam_shift_estimate(lam_center=630.15, L=1.496e11, alpha=0.5):
    ell_p = 1.616e-35
    return lam_center * (ell_p / L)**alpha

def extract_line_residual(lam, intensity, lam_expected):
    idx_peak = np.argmin(intensity)
    fit_range = slice(max(0, idx_peak - 5), min(len(lam), idx_peak + 6))
    p = np.polyfit(lam[fit_range], intensity[fit_range], 2)
    lam_peak = -p[1] / (2 * p[0])
    return lam_peak - lam_expected

if __name__ == "__main__":
    lam, obs = load_mock_solar_spectrum()
    delta_lambda_foam = foam_shift_estimate()
    residual = extract_line_residual(lam, obs, 630.15)

    print("Predicted foam shift (nm):", delta_lambda_foam)
    print("Observed line residual (nm):", residual)

    plt.figure(figsize=(10,4))
    plt.plot(lam, obs, label='Simulated NSO FTS')
    plt.axvline(630.15, color='gray', linestyle='--', label='Expected line center')
    plt.axvline(630.15 + residual, color='r', linestyle='--', label='Observed peak')
    plt.title("Solar Spectrum Line Residual vs. Quantum Foam Prediction")
    plt.xlabel("Wavelength (nm)")
    plt.ylabel("Normalized Intensity")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()
