
import numpy as np
from scipy.fft import fft, ifft, fftfreq

# Parameters
c = 3e8
L = 1e-3
N = 2048
dx = L / N
x = np.linspace(0, L, N, endpoint=False)
dt = 1e-15
T_total = 2e-13
Nt = int(T_total / dt)
kx = 2 * np.pi * fftfreq(N, d=dx)
correlation_length = L / 10
noise_spectrum = np.exp(-0.5 * (kx * correlation_length)**2)
sigma = 1e9
kappa = 1e8  # recursive phase-breaking parameter

# Initial fields
psi_fwd = np.exp(-((x - L/2)**2) / (2 * (L/20)**2)).astype(np.complex128)
psi_rev = psi_fwd.copy()
recursive_coherence = []

for n in range(Nt):
    xi_fwd = np.real(ifft(fft(np.random.normal(0, 1, N)) * np.sqrt(noise_spectrum)))
    g_fwd = sigma * np.tanh(xi_fwd)
    dpsi_dx_fwd = ifft(1j * kx * fft(psi_fwd))
    psi_fwd += dt * (1j * c * dpsi_dx_fwd) + g_fwd * psi_fwd * dt + kappa * np.conj(psi_fwd) * dt

    xi_rev = np.real(ifft(fft(np.random.normal(0, 1, N)) * np.sqrt(noise_spectrum)))
    g_rev = sigma * np.tanh(xi_rev)
    dpsi_dx_rev = ifft(-1j * kx * fft(psi_rev))
    psi_rev += dt * (1j * c * dpsi_dx_rev) + g_rev * psi_rev * dt + kappa * np.conj(psi_rev) * dt

    if n % 20 == 0:
        numerator = np.vdot(psi_fwd, psi_rev)
        denom = np.linalg.norm(psi_fwd) * np.linalg.norm(psi_rev)
        recursive_coherence.append(np.abs(numerator / denom))
