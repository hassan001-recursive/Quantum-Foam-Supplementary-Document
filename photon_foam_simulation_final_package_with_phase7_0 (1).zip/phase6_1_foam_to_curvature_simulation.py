
import numpy as np
from scipy.fft import fft, ifft, fftfreq
import matplotlib.pyplot as plt

# Parameters
c = 3e8
L = 1e-3
N = 2048
dx = L / N
x = np.linspace(0, L, N, endpoint=False)
dt = 1e-15
T_total = 2e-13
Nt = int(T_total / dt)
kx = 2 * np.pi * fftfreq(N, d=dx)
correlation_length = L / 10
noise_spectrum = np.exp(-0.5 * (kx * correlation_length)**2)
sigma = 1e9

# Initialize wavepacket
psi = np.exp(-((x - L/2)**2) / (2 * (L/20)**2)).astype(np.complex128)

# Evolve SPDE
for n in range(Nt):
    xi = np.real(ifft(fft(np.random.normal(0, 1, N)) * np.sqrt(noise_spectrum)))
    g = sigma * np.tanh(xi)
    dpsi_dx = ifft(1j * kx * fft(psi))
    psi += dt * (1j * c * dpsi_dx) + g * psi * dt

# Compute Ricci-like curvature proxy: second derivative of |psi|
psi_amp = np.abs(psi)
psi_amp_fft = fft(psi_amp)
ricci_proxy = np.real(ifft(-(kx**2) * psi_amp_fft))

# Plot result
plt.plot(x * 1e3, ricci_proxy)
plt.xlabel("Position x (mm)")
plt.ylabel("Ricci Proxy R(x)")
plt.title("Decoherence-Induced Curvature")
plt.grid(True)
plt.tight_layout()
plt.show()
