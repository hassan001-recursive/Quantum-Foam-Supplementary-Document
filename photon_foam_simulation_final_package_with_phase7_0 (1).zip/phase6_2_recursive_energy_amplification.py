
import numpy as np
import matplotlib.pyplot as plt

# Parameters
T_total = 1e-6
dt = 1e-9
Nt = int(T_total / dt)
t_series = np.linspace(0, T_total, Nt)

# Constants
pi = np.pi
e_charge = np.exp(1)
mass_energy = 1e-30
kappa = 1e20
r_exp = 3.5
eta = 1e21

# Recursive asymmetry variable K(t)
np.random.seed(42)
K_t = np.cumsum(np.random.choice([-1, 1], size=Nt, p=[0.45, 0.55]))

# Energy evolution
energy_amplified = []
for i, t in enumerate(t_series):
    E_t = np.sqrt(mass_energy**pi) + pi**np.log(np.abs(e_charge)) + kappa * (t**r_exp) + eta * (K_t[i]**2)
    energy_amplified.append(E_t)

# Plot result
plt.plot(t_series * 1e6, energy_amplified)
plt.xlabel("Time (μs)")
plt.ylabel("E(t)")
plt.title("Recursive Asymmetry Triggered Energy Amplification")
plt.grid(True)
plt.tight_layout()
plt.show()
