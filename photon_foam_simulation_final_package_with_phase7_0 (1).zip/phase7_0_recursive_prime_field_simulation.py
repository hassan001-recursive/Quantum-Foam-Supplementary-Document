
import numpy as np
from sympy import primerange
import matplotlib.pyplot as plt

# Parameters
N = 300
expected_primes = [2 + i * 2 for i in range(N)]
true_primes = list(primerange(1, 2000))[:N]

# Deviations from naive structure
delta_np = np.array(true_primes) - np.array(expected_primes)
log_pn = np.log(true_primes)
p_power_R = log_pn / np.sqrt(np.arange(1, N+1))
recursive_entropy = p_power_R + 1e-2 * delta_np

# Plot result
plt.plot(range(1, N + 1), recursive_entropy)
plt.xlabel("Prime Index n")
plt.ylabel("P⁽ᴿ⁾(n)")
plt.title("Recursive Prime Field Function")
plt.grid(True)
plt.tight_layout()
plt.show()
